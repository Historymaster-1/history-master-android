# HISTORY MASTER — Android app starter

This project wraps the existing HISTORY MASTER mobile web game in an Android WebView.
It is intentionally the first app build: no AdMob SDK is connected yet.

## Build from a phone
1. Create a GitHub repository named `history-master-android`.
2. Upload all files/folders from this project.
3. Open the repository's **Actions** tab.
4. Run **Build HISTORY MASTER Android App**.
5. Download the `HISTORY-MASTER-debug-apk` artifact and install it on the phone.

## Important
- The app loads the existing production game at:
  https://historymaster-1.netlify.app/
- AdMob is NOT connected yet.
- A Play Store release will later need a signed release build/AAB and the required Play Console setup.


## AdMob configuration
AdMob is now connected for HISTORY MASTER.

- AdMob App ID: `ca-app-pub-1230108983927436~7463166352`
- Banner Ad Unit ID: `ca-app-pub-1230108983927436/6929562318`

The Android wrapper displays the banner below the WebView.
During development, use AdMob test ads and do not click production ads yourself.
